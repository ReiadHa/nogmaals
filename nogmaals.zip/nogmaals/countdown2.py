x = 1
while x >=30:
    print(x)