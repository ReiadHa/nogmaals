import time
x = 20
while x <=50: 
    time.sleep(0.2)
    print(x)
    x = x + 2
    
    
   






































   

