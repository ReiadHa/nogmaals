import time

x = 30
while x >=1:
    time.sleep(1)
    print(x)
    x = x -1
    if x == 0 :
        print('raketlaunch')